#1. lista.h — interface do TAD

#ifndef LISTA_H
#define LISTA_H
typedef struct No {
    int valor;
    struct No *proximo;
} No;
typedef struct {
    No *cabeca;
    int tamanho;
} Lista;
void inicializar(Lista *l);
int insert(Lista *l, int pos, int valor);
void show(Lista *l);
int acessar(Lista *l, int pos, int *valor);
int remover(Lista *l, int pos);
void liberar(Lista *l);
#endif


# 2. — implementação

#include <stdio.h>
#include <stdlib.h>
#include "lista.h"
void inicializar(Lista *l) {
    l->cabeca = NULL;
    l->tamanho = 0;
}
int insert(Lista *l, int pos, int valor) {
    if (pos < 0 || pos > l->tamanho) {
        return 0;
    }
    No *novo = (No *) malloc(sizeof(No));
    if (novo == NULL) {
        return 0;
    }
    novo->valor = valor;
    /* Caso 1: inserir na cabeça */
    if (pos == 0) {
        novo->proximo = l->cabeca;
        l->cabeca = novo;
    }
    /* Caso 2: inserir no meio ou no fim */
    else {
        No *anterior = l->cabeca;
        for (int i = 0; i < pos - 1; i++) {
        }
            anterior = anterior->proximo;
        novo->proximo = anterior->proximo;
        anterior->proximo = novo;
    }
    l->tamanho++;
    return 1;
}
void show(Lista *l) {
    No *p = l->cabeca;
    while (p != NULL) {
        printf("%d -> ", p->valor);
        p = p->proximo;
    }
    printf("NULL\n");
}
int acessar(Lista *l, int pos, int *valor) {
    if (pos < 0 || pos >= l->tamanho) {
        return 0;
    }
    No *p = l->cabeca;
    for (int i = 0; i < pos; i++) {
        p = p->proximo;
    }
    *valor = p->valor;
    return 1;
}
int remover(Lista *l, int pos) {
    if (pos < 0 || pos >= l->tamanho) {
        return 0;
    }
    No *removido;
    /* Caso 1: remover a cabeça */
    if (pos == 0) {
        removido = l->cabeca;
        l->cabeca = l->cabeca->proximo;
    }
    /* Caso 2: remover do meio ou do fim */
    else {
        No *anterior = l->cabeca;
        for (int i = 0; i < pos - 1; i++) {
            anterior = anterior->proximo;
        }
        removido = anterior->proximo;
        anterior->proximo = removido->proximo;
    }
    free(removido);
    l->tamanho--;
    return 1;
}
void liberar(Lista *l) {
    No *p = l->cabeca;
    while (p != NULL) {
        No *proximo = p->proximo;
        free(p);
        p = proximo;
    }
    l->cabeca = NULL;
    l->tamanho = 0;
}
  

# 3. — teste das operações

#include <stdio.h>
#include "lista.h"
int main() {
    Lista lista;
    int valor;
    inicializar(&lista);
    /* Inserindo no final */
    insert(&lista, 0, 10);
    insert(&lista, 1, 20);
    insert(&lista, 2, 30);
    printf("Lista inicial: ");
    show(&lista);
    /* Inserindo no meio */
    insert(&lista, 1, 15);
    printf("Depois de inserir 15 na posicao 1: ");
    show(&lista);
    /* Acessando uma posição */
    if (acessar(&lista, 2, &valor)) {
        printf("Valor na posicao 2: %d\n", valor);
    }
    /* Removendo um nó */
    remover(&lista, 1);
    printf("Depois de remover a posicao 1: ");
    show(&lista);
    printf("Tamanho: %d\n", lista.tamanho);
    /* Libera todos os nós */
    liberar(&lista);
    return 0;
}


4. Como funciona o insert:
# Para inserir na posição pos, primeiro
encontramos o nó anterior à posição desejada. Depois, dois ponteiros precisam ser ligados corretamente.
Ordem correta: primeiro fazemos novo->proximo = anterior->proximo. Depois fazemos
anterior->proximo = novo. Isso evita perder o restante da lista.
Antes:
10 -> 20 -> 30 -> NULL
Inserir 15 na posição 1:
novo->proximo = anterior->proximo;
10 -> 20 -> 30
     ^
     novo aponta para 20
Depois:
anterior->proximo = novo;
10 -> 15 -> 20 -> 30 -> NULL
5. Como funciona o remover
Para remover um nó do meio, encontramos o nó anterior. O anterior passa a apontar para o nó seguinte ao
que será removido. Só depois liberamos a memória do nó removido.
Antes:
10 -> 20 -> 30 -> NULL
Remover 20:
anterior->proximo = removido->proximo;
Depois:
10 -> 30 -> NULL
free(removido);
